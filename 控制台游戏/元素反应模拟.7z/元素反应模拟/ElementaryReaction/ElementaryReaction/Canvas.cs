﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ElementalReaction
{
    class Canvas
    {
        public static Canvas Instance;
        public static int height = 20;
        public static int width = 40;
        public static int ox = 10;
        public static int oy = 5;
        static string[,] buffer = new string[width + ox, height + oy];
        static string[,] backbuffer = new string[buffer.GetLength(0), buffer.GetLength(1)];
        static ConsoleColor[,] colorbuffer = new ConsoleColor[buffer.GetLength(0), buffer.GetLength(1)];
        public Canvas()
        {
            Instance = this;
        }
        public void Refresh(Player player, Enemy enemy)
        {
            //Clear buffer
            Copybuffer();
            for (int i = 0; i < buffer.GetLength(0); i++)
            {
                for (int j = 0; j < buffer.GetLength(1); j++)
                {
                    buffer[i, j] = " ";
                    colorbuffer[i, j] = ConsoleColor.Gray;
                }
            }
            //map buffer
            for (int i = oy; i < height + oy; i++)
            {
                for (int j = ox; j < width + ox; j++)
                {
                    if (i == oy)
                    {
                        buffer[i, j] = "#";
                    }
                    else if (i == height + oy - 1)
                    {
                        buffer[i, j] = "#";
                    }
                    else if (j == ox)
                    {
                        buffer[i, j] = "#";
                    }
                    else if (j == width + ox - 1)
                    {
                        buffer[i, j] = "#";
                    }
                    /*                    else
                                        {
                                            buffer[i, j] = " ";
                                        }*/
                }
            }

            // draw Player
            int posX = player.posX;
            int posY = player.posY;
            buffer[posY + oy, posX + ox] = player.symbol;
            colorbuffer[posY + oy, posX + ox] = ConsoleColor.DarkYellow;

            //draw Enemy
            int enemyPosX = enemy.posX + ox;
            int enemyPosY = enemy.posY + oy;

            buffer[enemyPosY, enemyPosX] = enemy.symbol;
            //buffer[ox - 1, oy] = "Score: " + score;
            Console.SetCursorPosition(enemyPosX + 5, enemyPosY + 1);
            Console.Write(enemy.name);

            //用了colorcanvas的代码,解决了屏闪问题
            for (int i = 0; i < buffer.GetLength(0); i++)
            {
                int end = 0;
                for (int j = buffer.GetLength(1) - 1; j >= 0; j--)
                {
                    if (buffer[i, j] != " " || backbuffer[i, j] != " ")
                    {
                        end = j + 1;
                        break;
                    }
                }
                for (int j = 0; j < end; j++)
                {
                    if (backbuffer[i, j] != buffer[i, j])
                    {
                        Console.SetCursorPosition(j * 2, i);
                        Console.ForegroundColor = colorbuffer[i, j];
                        Console.Write(buffer[i, j]);
                    }
                }
            }
            /*            //print score
                        //buffer[ox - 1, oy] = "Score: " + score;
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.SetCursorPosition(ox + 5, oy - 1);
                        Console.Write($"Score: {score}");*/
            /*            DateTime endTime = DateTime.Now;
                        Console.WriteLine((endTime - startTime).TotalMilliseconds);*/
        }
        public void Copybuffer()
        {
            for (int i = 0; i < buffer.GetLength(0); i++)
            {
                for (int j = 0; j < buffer.GetLength(1); j++)
                {
                    backbuffer[i, j] = buffer[i, j];
                }
            }

        }
    }
}
