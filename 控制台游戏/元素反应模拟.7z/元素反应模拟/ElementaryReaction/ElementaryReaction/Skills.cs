﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ElementalReaction
{
    class Skill
    {
        public Element element { get; private set; }
        public float damage { get; private set; } = 10;

    public Skill(Element element, float damage)
        {
            this.element = element;
            this.damage = damage;
        }

        public override string ToString()
        {
            return $"Type: {this.element.elementType}, Damage: {damage}";
        }
    }
}
