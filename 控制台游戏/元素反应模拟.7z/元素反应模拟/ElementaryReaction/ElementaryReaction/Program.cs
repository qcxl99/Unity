﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ElementalReaction
{
    class Program
    {
        static int height = 20;
        static int width = 20;
        public static int ox = 5;
        public static int oy = 5;
        static int skill = 12;
        static int second = 0;
        static float time = 0;
        static int deltaTime = 100;
        static ConsoleKeyInfo input;
        static bool canMove = true;
        static bool isAttack;
        //battle
        static bool battle = false;
        static string damageNum = " ";
        public static string[,] buffer = new string[width + ox, height + oy];
        static string[,] backbuffer = new string[buffer.GetLength(0), buffer.GetLength(1)];
        public static ConsoleColor[,] colorbuffer = new ConsoleColor[buffer.GetLength(0), buffer.GetLength(1)];
        static void Main(string[] args)
        {
            //Create elements
            Element None = new Element(ElementType.None, ElementLevel.S, 0, true);
            Element SFire = new Element(ElementType.Fire, ElementLevel.S, Element.Squantity, true);
            Element MIce = new Element(ElementType.Ice, ElementLevel.M, Element.Mquantity, true);
            Element SWater = new Element(ElementType.Water, ElementLevel.S, Element.Squantity, true);
            Element sWater = new Element(ElementType.Water, ElementLevel.s, Element.squantity, true);
            Element SElectro = new Element(ElementType.Electro, ElementLevel.S, Element.Squantity, true);
            Element sElectro = new Element(ElementType.Electro, ElementLevel.s, Element.squantity, true);
            Element SDendro = new Element(ElementType.Dendro, ElementLevel.S, Element.Squantity, true);
            //Creat skills
            Skill normalkill0 = new Skill(None, 50);
            Skill fireSkill0 = new Skill(SFire, 50);
            Skill iceSkill0 = new Skill(MIce, 40);
            Skill waterSkill0 = new Skill(SWater, 40);
            Skill waterSkill1 = new Skill(sWater, 20);
            Skill electroSkill0 = new Skill(SElectro, 50);
            Skill electroSkill1 = new Skill(sElectro, 30);
            Skill dendroSkill0 = new Skill(SDendro, 40);
            //Add skills in player's skill list
            List<Skill> skills = new List<Skill>() ;
            skills.Add(normalkill0);
            skills.Add(fireSkill0);
            skills.Add(iceSkill0);
            skills.Add(waterSkill0);
            skills.Add(waterSkill1);
            skills.Add(electroSkill0);
            skills.Add(electroSkill1);
            skills.Add(dendroSkill0);
            //create player and enemy
            Player player = new Player(1, skills);
            Enemy enemy1 = new Enemy("", "O", 100, new Element(ElementType.None, ElementLevel.M, 2, true),State.None, new Random().Next(2,15), new Random().Next(2, 15));
            //Create new thread to keep main program and attack running in the mean time
            ThreadStart chooseSkill = new ThreadStart(Attack);
            Thread attack = new Thread(chooseSkill);
            attack.Start();
            //time count in element reducing
            int timeCount = 0;
            while (true)  
            {
                //main cycle
                time = 0;
                //Clear buffer
                Copybuffer();
                for (int i = 0; i < buffer.GetLength(0); i++)
                {
                    for (int j = 0; j < buffer.GetLength(1); j++)
                    {
                        buffer[i, j] = " ";
                        colorbuffer[i, j] = ConsoleColor.Gray;
                    }
                }
                //when canMove =true, move function can be called
                if (canMove)
                {
                    player.Move(input);
                    canMove = false;
                }

                int enemyPosX = enemy1.posX + ox;
                int enemyPosY = enemy1.posY + oy;
                int damageNumY = enemy1.posY + oy - 1;
                int damageNumX = enemy1.posX + ox - 1;
                Refresh(player, enemy1);
                if(player.posX == enemy1.posX && player.posY == enemy1.posY)
                {
                    battle = true;
                    player.symbol = string.Empty;
                    //start battle cycle
                    while (battle)
                    {
                        int oneSecond = 1000 / deltaTime;
                        //copy and clear buffer
                        Copybuffer();
                        for (int i = 0; i < buffer.GetLength(0); i++)
                        {
                            for (int j = 0; j < buffer.GetLength(1); j++)
                            {
                                buffer[i, j] = " ";
                                colorbuffer[i, j] = ConsoleColor.Gray;
                            }
                        }
                        //if enemy hp <0, clear console and creat a  new
                        if (enemy1.hp <= 0)
                        {
                            damageNum = " ";
                            Thread.Sleep(400);
                            Console.Clear();
                            Copybuffer();
                            battle = false;

                            enemy1 = new Enemy("Slime", "O", 1000, new Element(ElementType.None, ElementLevel.M, 2, true), State.None, new Random().Next(2, 15), new Random().Next(2, 15));
                            break;
                        }
                        //state, at first excute state quantity >0,then inspecte if quantity <0
                        switch (enemy1.state)
                        {
                            case State.None:
                                {
                                    break;
                                }
                            case State.Frozen:
                                {
                                    second++;
                                    if (enemy1.frozenQ > 0)
                                    {
                                        damageNum = "冻结";
                                        colorbuffer[enemyPosY - 1, enemyPosX - 1] = ConsoleColor.Blue;
                                        if (second >= oneSecond)
                                        {
                                            second = 0;
                                            enemy1.frozenQ -= (0.4f + 0.1f * second);
                                        }

                                    }
                                    if(enemy1.frozenQ <= 0)
                                    {
                                        enemy1.frozenQ = 0;
                                        second = 0;

                                        damageNum = " ";
                                        Console.Clear();
                                        Copybuffer();
                                        colorbuffer[enemyPosY - 1, enemyPosX - 1] = ConsoleColor.Gray;
                                        enemy1.state = State.None;
                                        break;

                                    }
                                    break;

                                }
                            case State.Burning:
                                {
                                    second++;
                                    if (enemy1.burnQ >= 0 && enemy1.element.quantity > 0 && second >= 0.5f * oneSecond)
                                    {
                                        second = 0;
                                        enemy1.burnQ -= 0.2f;
                                        enemy1.element.quantity -= 0.2f;
                                        float damage = 0.5f * fireSkill0.damage;
                                        enemy1.hp -= damage;
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.WriteLine("                ");
                                        Console.WriteLine($"{enemy1.name} get {((int)damage)} damage");
                                        damageNum = "燃烧";

                                        colorbuffer[enemyPosY - 1, enemyPosX - 1] = ConsoleColor.Red;
                                        Console.ForegroundColor = ConsoleColor.Gray;

                                    }
                                    if (enemy1.burnQ <= 0 || enemy1.element.quantity <= 0)
                                    {
                                        second = 0;
                                        damageNum = " ";
                                        Console.Clear();
                                        Copybuffer();
                                        colorbuffer[enemyPosY - 1, enemyPosX - 1] = ConsoleColor.Gray;
                                        enemy1.burnQ = 0;
                                        enemy1.state = State.None;
                                        break;
                                    }


                                    break;
                                }
                            case State.ElectroCharged:
                                {
                                    second++;

                                    if (enemy1.chargeQ >= 0 && enemy1.element.quantity > 0 && second >= oneSecond)
                                    {
                                        second =0;
                                        enemy1.chargeQ -= 0.4f;
                                        enemy1.element.quantity -= 0.4f;
                                        float damage = 0.6f * electroSkill0.damage;
                                        enemy1.hp -= damage;
                                        damageNum = "感电 ";
                                        Console.ForegroundColor = ConsoleColor.Magenta;
                                        Console.WriteLine("             ");
                                        Console.WriteLine($"{enemy1.name} get {((int)damage)} damage");
                                        colorbuffer[enemyPosY - 1, enemyPosX - 1] = ConsoleColor.Magenta;
                                        second++;
                                        Console.ForegroundColor = ConsoleColor.Gray;
                                        
                                    }
                                    if (enemy1.chargeQ <= 0 || enemy1.element.quantity <= 0)
                                    {
                                        second = 0;

                                        damageNum = "         ";
                                        Console.Clear();
                                        Copybuffer();
                                        colorbuffer[enemyPosY - 1, enemyPosX - 1] = ConsoleColor.Gray;
                                        enemy1.chargeQ = 0;
                                        enemy1.state = State.None;
                                        break;
                                    }
                                    break;


                                }
                            case State.Quiken:
                                {
                                    second++;
                                    if (enemy1.quikenQ <= 0 || second > 10 * oneSecond)
                                    {
                                        second = 0;
                                        Console.Clear();
                                        Copybuffer();
                                        enemy1.quikenQ = 0;
                                        enemy1.state = State.None;
                                        break;
                                    }

                                    break;
                                }
                            case State.Bloom:
                                {
                                    second++;
                                    if (enemy1.bloomQ <= 0 || second > 10* oneSecond)
                                    {
                                        second = 0;

                                        Console.Clear();
                                        Copybuffer();
                                        enemy1.bloomQ = 0;
                                        enemy1.state = State.None;
                                        break;
                                    }
                                    break;
                                }
                        }
                        //element reduce in fixed time
                        if (enemy1.element.elementType != ElementType.None )
                        {
                            timeCount++;
                            if(enemy1.element.quantity > 0 && enemy1.frozenQ <= 0 &&  enemy1.burnQ <= 0 && timeCount >= oneSecond)
                            {
                                timeCount = 0;
                                if (enemy1.element.elementLevel == ElementLevel.S)
                                {
                                    enemy1.element.quantity -= Element.Squantity * 0.8f / 17;
                                    time = enemy1.element.quantity / Element.Squantity / 0.8f * 17;
                                }
                                else if (enemy1.element.elementLevel == ElementLevel.M)
                                {
                                    enemy1.element.quantity -= Element.Mquantity * 0.8f / 12;
                                    time = enemy1.element.quantity / Element.Mquantity / 0.8f * 12;
                                }
                                else if (enemy1.element.elementLevel == ElementLevel.s)
                                {
                                    enemy1.element.quantity -= Element.squantity * 0.8f / 9;
                                    time = enemy1.element.quantity / Element.squantity / 0.8f * 9;
                                }
                            }
                            else if (enemy1.element.quantity <= 0)
                            {
                                timeCount = 0;
                                enemy1.element = None;
                            }

                        }
                        //if state quantity <=0; reset in zero
                        if (enemy1.chargeQ < 0 || enemy1.burnQ < 0 || enemy1.bloomQ < 0 || enemy1.quikenQ < 0 || second > oneSecond * 10)
                        {
                            second = 0;
                            enemy1.chargeQ = 0;
                            enemy1.burnQ = 0;
                            enemy1.bloomQ = 0;
                            enemy1.quikenQ = 0;

                            

                        }

                        //Console.WriteLine($"bloomQ:{enemy1.bloomQ}\nburnQ: {enemy1.burnQ}\nchargeQ: {enemy1.chargeQ}\nfrozenQ: {enemy1.frozenQ}\nquikenQ: {enemy1.quikenQ}");
                        
                        //choose skill and attack(execute enemy gethit function)
                        if (skill < skills.Count && isAttack)
                        {
                            if (enemy1.state == State.Frozen)
                            {
                                enemy1.GetHit(ElementType.Ice, skills[skill]);
                                isAttack = false;
                                skill = 12;
                            }
                            else if (enemy1.state == State.Burning)
                            {
                                enemy1.GetHit(ElementType.Fire, skills[skill]);
                                isAttack = false;
                                skill = 12;
                            }
                            else if (enemy1.state == State.ElectroCharged)
                            {
                                enemy1.GetHit(ElementType.Electro, skills[skill]);
                                isAttack = false;
                                skill = 12;
                            }
                            else
                            {
                                enemy1.GetHit(enemy1.element.elementType, skills[skill]);
                                isAttack = false;
                                skill = 12;
                            }
                            

                        }
                        // redender image
                        Refresh(player, enemy1);
                        //Reset elements
                        None = new Element(ElementType.None, ElementLevel.S, 0, true);
                        SFire = new Element(ElementType.Fire, ElementLevel.S, Element.Squantity, true);
                        MIce = new Element(ElementType.Ice, ElementLevel.M, Element.Mquantity, true);
                        SWater = new Element(ElementType.Water, ElementLevel.S, Element.Squantity, true);
                        sWater = new Element(ElementType.Water, ElementLevel.s, Element.squantity, true);
                        SElectro = new Element(ElementType.Electro, ElementLevel.S, Element.Squantity, true);
                        sElectro = new Element(ElementType.Electro, ElementLevel.s, Element.squantity, true);
                        SDendro = new Element(ElementType.Dendro, ElementLevel.S, Element.Squantity, true);
                        //Reset skills
                        normalkill0 = new Skill(None, 50);
                        fireSkill0 = new Skill(SFire, 50);
                        iceSkill0 = new Skill(MIce, 40);
                        waterSkill0 = new Skill(SWater, 40);
                        waterSkill1 = new Skill(sWater, 20);
                        electroSkill0 = new Skill(SElectro, 50);
                        electroSkill1 = new Skill(sElectro, 30);
                        dendroSkill0 = new Skill(SDendro, 40);
                        //reset skill list
                        skills = new List<Skill>() { normalkill0, fireSkill0, iceSkill0, waterSkill0, waterSkill1, electroSkill0, electroSkill1, dendroSkill0 };
                        
                        Thread.Sleep(deltaTime);
                        
                    }
                    //when enemy is dead
                    Console.SetCursorPosition(0, oy + height);
                    Console.WriteLine("Slime is down  ");
                    player.symbol = "P";
                }
                Thread.Sleep(deltaTime);
            }
                
                
                
        }
        
        public static void Attack()
        {
            while (true)
            {
                //move input
                while (Console.KeyAvailable)
                {
                    input = Console.ReadKey(true);
                    canMove = true;
                }
                //skill number
                if ((int)input.Key >= 48 &&isAttack)
                {
                    skill = (int)input.Key;
                    skill -= 48;
  
                }
                else if ((int)input.Key >= 96 && isAttack)
                {
                    skill = (int)input.Key;

                    skill -= 96;
                    
                }

            }

        }
 

        public static void Refresh(Player player, Enemy enemy)
        {

            
            //map buffer
            for (int i = oy; i < height + oy; i++)
            {
                for (int j = ox; j < width + ox; j++)
                {
                    if (i == oy)
                    {
                        buffer[i, j] = "#";
                    }
                    else if (i == height + oy - 1)
                    {
                        buffer[i, j] = "#";
                    }
                    else if (j == ox)
                    {
                        buffer[i, j] = "#";
                    }
                    else if (j == width + ox - 1)
                    {
                        buffer[i, j] = "#";
                    }
                    /*                    else
                                        {
                                            buffer[i, j] = " ";
                                        }*/
                }
            }

            // draw Player if not in battle
            if (!battle)
            {
                int posX = player.posX;
                int posY = player.posY;
                buffer[posY + oy, posX + ox] = player.symbol;
                colorbuffer[posY + oy, posX + ox] = ConsoleColor.DarkYellow;
            }


            //draw Enemy
            int enemyPosX = enemy.posX + ox;
            int enemyPosY = enemy.posY + oy;
            int damageNumY = enemy.posY + oy - 1;
            int damageNumX = enemy.posX + ox - 1;
            buffer[enemyPosY, enemyPosX] = enemy.symbol;
            buffer[enemyPosY + 1,enemyPosX - 1] = enemy.name;
            //print damage number
            buffer[damageNumY, damageNumX] = damageNum;
            //用了colorcanvas的代码,解决了屏闪问题
            for (int i = 0; i < buffer.GetLength(0); i++)
            {
                int end = 0;
                for (int j = buffer.GetLength(1) - 1; j >= 0; j--)
                {
                    if (buffer[i, j] != " " || backbuffer[i, j] != " ")
                    {
                        end = j + 1;
                        break;
                    }
                }
                for (int j = 0; j < end; j++)
                {
                    if (backbuffer[i, j] != buffer[i, j])
                    {
                        Console.SetCursorPosition(j*2 , i);
                        Console.ForegroundColor = colorbuffer[i, j];
                        Console.Write(buffer[i, j]);
                        
                    }
                }
            }
            Console.ForegroundColor = ConsoleColor.Gray;
            //Print skills when start a battle
            if (battle)
            {
                StringBuilder showSkill = new StringBuilder();
                Console.SetCursorPosition(width + ox + 5, height + oy + 1);
                if(enemy.element.elementType != ElementType.None && enemy.state == State.None)
                {
                    Console.Write($"{enemy.element.elementType}: {((int)time)}   ");
                }
                else
                {
                    Console.Write("                               ");
                }

                if (input.Key == ConsoleKey.Q)
                {
                    isAttack = true;
                    showSkill.AppendLine("Select skills: ");
                    for (int i = 0; i < player.skills.Count; i++)
                    {
                        showSkill.Append(i);
                        showSkill.Append(": ");
                        showSkill.Append(player.skills[i]);
                        showSkill.Append("\n");
                    }
                }
                else
                {
                    isAttack = false;
                    showSkill.Clear();
                    showSkill.AppendLine("Q Select skills");
                    for (int i = 0; i < player.skills.Count; i++)
                    {
                        showSkill.AppendLine("                            ");

                    }

                }
                Console.SetCursorPosition(0, height + 5);
                Console.Write(showSkill);
            }
        }
        public static void Copybuffer()
        {
            for (int i = 0; i < buffer.GetLength(0); i++)
            {
                for (int j = 0; j < buffer.GetLength(1); j++)
                {
                    backbuffer[i, j] = buffer[i, j];
                }
            }

        }


    }
}
