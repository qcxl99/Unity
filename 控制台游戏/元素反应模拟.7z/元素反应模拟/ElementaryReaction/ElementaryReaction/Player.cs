﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ElementalReaction
{
    public enum PlayerState
    {
        none,
        up,
        down,
        left,
        right,
        Attack

    }
    class Player
    {
        int attack = 1;
        public List<Skill> skills = new List<Skill>();
        public List<Element> onBody = new List<Element>();
        public string symbol = "P";
        public int posX = 1;
        public int posY = 1;
        public PlayerState playerState;

        public Player()
        {
        }

        public Player(int attack, List<Skill> skills)
        {
            this.attack = attack;
            this.skills = skills;
        }

        public Player(int attack, List<Skill> skills, string symbol, int posX, int posY, PlayerState playerState) : this(attack, skills)
        {
            this.symbol = symbol;
            this.posX = posX;
            this.posY = posY;
            this.playerState = playerState;
        }

        public void Move(ConsoleKeyInfo input)
        {

            switch (input.Key)
            {
                case ConsoleKey.Spacebar:
                    {
                        posX = posY = 1;
                        break;
                    }
                case ConsoleKey.UpArrow:
                    {
                        if (posY >  1)
                        {
                            posY--;
                        }
                        

                        break;
                    }
                case ConsoleKey.DownArrow:
                    {
                        if (posY < Canvas.height - 2 )
                        {
                            posY++;
                        }

                        break;
                    }
                case ConsoleKey.LeftArrow:
                    {
                        if (posX >  1)
                        {
                            posX--;
                        }
                        break;
                    }
                case ConsoleKey.RightArrow:
                    {
                        if (posX < Canvas.width - 2)
                        {
                            posX++;
                        }
                        break;
                    }
                default:
                    {
                        playerState = PlayerState.none;
                        break;
                    }
            }

        }
    }
}
