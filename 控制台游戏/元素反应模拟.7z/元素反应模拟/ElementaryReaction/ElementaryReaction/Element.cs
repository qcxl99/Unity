﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ElementalReaction
{
    public enum ElementType
    {
        None,
        Fire,
        Water,
        Electro,
        Ice,
        Dendro
    }
    public enum ElementLevel
    {
        S,
        M,
        s
    }
    class Element
    {
        public ElementType elementType;
        public ElementLevel elementLevel;
        public float quantity;
        public static float Squantity = 4;
        public static float Mquantity = 2;
        public static float squantity = 1;
        bool isAttack = false;
        
        public Element(ElementType elementType, ElementLevel elementLevel, float quantity, bool isAttack)
        {
            this.elementType = elementType;
            this.elementLevel = elementLevel;
            this.quantity = quantity;
            this.isAttack = isAttack;
        }
    }

}
