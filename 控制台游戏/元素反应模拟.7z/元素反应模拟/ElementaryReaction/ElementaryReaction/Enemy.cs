﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ElementalReaction
{
    public enum State
    {
        None,
        Frozen,
        Burning,
        ElectroCharged,
        Quiken,
        Bloom
    }
    class Enemy
    {
        public string name = " ";
        public string symbol;
        public int maxHp = 100;
        public float hp;
        public Element element;
        public State state;
        public Dictionary<float,Element> onBody = new Dictionary<float, Element>();
        public float frozenQ=0;
        public float burnQ=0;
        public float quikenQ;
        public float bloomQ;
        public float chargeQ;
        public int posX = 5;
        public int posY = 5;
        public Enemy()
        {
        }
        public Enemy(string name, string symbol, int maxHp)
        {
            this.name = name;
            this.symbol = symbol;
            this.maxHp = maxHp;
            hp = maxHp;
        }
        public Enemy(string name, string symbol, int maxHp, Element element)
        {
            this.name = name;
            this.symbol = symbol;
            this.maxHp = maxHp;
            hp = maxHp;
            this.element = element;
        }

        public Enemy(string name, string symbol, int maxHp, Element Element, State state, int posX, int posY) : this(name, symbol, maxHp, Element)
        {
            hp = maxHp;
            this.state = state;
            this.posX = posX;
            this.posY = posY;
        }
        // Be hit and element reaction
        public Element GetHit(ElementType elementType,Skill skill)
        {
            float damage = skill.damage;
            //Reaction state
            if(state == State.Bloom)
            {
                if (bloomQ > 0 && skill.element.elementType == ElementType.Fire)
                {
                    hp -= 1.5f * damage;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("烈绽放           ");
                    Console.WriteLine($"{name} get {skill.damage} damage");
                    Thread.Sleep(400);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    bloomQ -= skill.element.quantity;
                    element.quantity -= skill.element.quantity;
                }
                else if (bloomQ > 0 && skill.element.elementType == ElementType.Electro)
                {
                    hp -= 1.5f * damage;
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine("超绽放           ");
                    Console.WriteLine($"{name} get {skill.damage} damage");
                    Thread.Sleep(400);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    bloomQ -= skill.element.quantity;
                    element.quantity -= skill.element.quantity;
                }
            }
            else if(state == State.Quiken)
            {

                if (quikenQ > 0 && skill.element.elementType == ElementType.Dendro)
                {
                    hp -= 1.5f * damage;
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("蔓激化            ");
                    Console.WriteLine($"{name} get {skill.damage} damage");
                    Thread.Sleep(400);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    quikenQ -= skill.element.quantity;
                    element.quantity -= skill.element.quantity;

                }
                else if (quikenQ > 0 && skill.element.elementType == ElementType.Electro)
                {
                    hp -= 1.5f * damage;
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine("超激化            ");
                    Console.WriteLine($"{name} get {skill.damage} damage");
                    Thread.Sleep(400);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    quikenQ -= skill.element.quantity;
                    element.quantity -= skill.element.quantity;
                }
            }
            switch (elementType)
            {
                // No element
                case ElementType.None:
                    {
                        Element skillElem = skill.element;
                        element = skillElem;
                        hp -= damage;
                        Console.WriteLine("                     ");
                        Console.WriteLine($"{name} get {skill.damage} damage");
                        
                        element.quantity = skillElem.quantity * 0.8f;
                        
                        break;
                    }
                    //Fire element reaction
                case ElementType.Fire:
                    {
                        //fire
                        if (skill.element.elementType == ElementType.Fire)
                        {
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                   ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            SameElemental(skill.element);
                        }
                        // water
                        else if (skill.element.elementType == ElementType.Water)
                        {
                            damage *= 2f;
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.DarkYellow;
                            Console.WriteLine("蒸发               ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            element.quantity -= 2 * skill.element.quantity;
                        }
                        //ice
                        else if (skill.element.elementType == ElementType.Ice )
                        {
                            damage *= 1.5f;
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.DarkYellow;
                            Console.WriteLine("融化                ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            element.quantity -= 0.5f * skill.element.quantity;
                        }
                        //electro
                        else if (skill.element.elementType == ElementType.Electro)
                        {
                            damage *= 1.5f;
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.WriteLine("超载                ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            element.quantity -=  skill.element.quantity;
                        }
                        //dendro
                        else if (skill.element.elementType == ElementType.Dendro)
                        {
                            
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("燃烧              ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            if (skill.element.quantity <= element.quantity)
                            {
                                burnQ += skill.element.quantity;
                            }
                            else if (skill.element.quantity > element.quantity)
                            {
                                burnQ += element.quantity;

                            }
                            state = State.Burning;
                        }
                        element.elementLevel = skill.element.elementLevel;
                        break;
                    }
                    // water element reaction
                case ElementType.Water:
                    {
                        // water
                        if (skill.element.elementType== ElementType.Water)
                        {
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.DarkBlue;
                            Console.WriteLine("                   ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            SameElemental(skill.element);
                        }
                        //fire
                        else if(skill.element.elementType == ElementType.Fire)
                        {
                            damage *= 1.5f;
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.DarkYellow;
                            Console.WriteLine("蒸发                ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            element.quantity -= 0.5f * skill.element.quantity;
                        }
                        //ice
                        else if (skill.element.elementType == ElementType.Ice )
                        {
                            
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.WriteLine("冻结               ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            if (skill.element.quantity <= element.quantity)
                            {
                                frozenQ = 2 * skill.element.quantity;
                            }
                            else if (skill.element.quantity > element.quantity)
                            {
                                frozenQ = 2 * element.quantity;
                            }
                            element.quantity -=  skill.element.quantity;
                            state = State.Frozen;
                        }
                        //electro-charged
                        else if (skill.element.elementType == ElementType.Electro)
                        {
                            
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.Magenta;
                            Console.WriteLine("感电                ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            if (skill.element.quantity <= element.quantity)
                            {
                                chargeQ += skill.element.quantity;
                            }
                            else if (skill.element.quantity > element.quantity)
                            {
                                chargeQ += element.quantity;
                            }
                            state = State.ElectroCharged;
                        }
                        //water enter bloom state 
                        else if (skill.element.elementType == ElementType.Dendro)
                        {

                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("绽放                ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            if (skill.element.quantity <= element.quantity)
                            {
                                bloomQ += 2 * skill.element.quantity;
                            }
                            else if ( 2* skill.element.quantity > element.quantity)
                            {
                                bloomQ += element.quantity;
                            }
                            state = State.Bloom;
                        }
                        element.elementLevel = skill.element.elementLevel;
                        break;
                    }
                    //ice element reaction
                case ElementType.Ice:
                    {
                        //ice
                        if (skill.element.elementType == ElementType.Ice)
                        {
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.WriteLine("                   ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            SameElemental(skill.element);
                        }
                        //fire
                        else if (skill.element.elementType == ElementType.Fire)
                        {
                            damage *= 2f;
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.DarkYellow;
                            Console.WriteLine("融化              ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            element.quantity -= 0.5f * skill.element.quantity;
                            frozenQ = 0;
                        }
                        //water enter frozen state
                        else if (skill.element.elementType == ElementType.Water)
                        {

                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.WriteLine("冻结               ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            if (skill.element.quantity <= element.quantity)
                            {
                                frozenQ += 2 * skill.element.quantity;
                            }
                            else if (skill.element.quantity > element.quantity)
                            {
                                frozenQ += 2 * element.quantity;
                            }
                            element.quantity -= skill.element.quantity;
                            state = State.Frozen;
                        }
                        //electro
                        else if (skill.element.elementType == ElementType.Electro)
                        {

                            hp -= 1.5f * damage;
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.WriteLine("超导             ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            element.quantity -= skill.element.quantity;
                            frozenQ -= skill.element.quantity;
                        }
                        element.elementLevel = skill.element.elementLevel;
                        break;
                    }
                    //electro element reaction
                case ElementType.Electro:
                    {
                        if (skill.element.elementType == ElementType.Electro)
                        {
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.Magenta;
                            Console.WriteLine("                  ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            SameElemental(skill.element);
                        }
                        //Fire 
                        else if (skill.element.elementType == ElementType.Fire)
                        {
                            damage *= 1.5f;
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.WriteLine("超载               ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            element.quantity -= skill.element.quantity;
                        }
                        else if (skill.element.elementType == ElementType.Ice)
                        {
                            damage *= 1.5f;
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.WriteLine("超导               ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            element.quantity -= skill.element.quantity;
                        }
                        else if (skill.element.elementType == ElementType.Water)
                        {
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.Magenta;
                            Console.WriteLine("感电               ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            if (skill.element.quantity <= element.quantity)
                            {
                                chargeQ += skill.element.quantity;
                            }
                            else if (skill.element.quantity > element.quantity)
                            {
                                chargeQ += element.quantity;
                            }
                            state = State.ElectroCharged;
                        }
                        else if (skill.element.elementType == ElementType.Dendro)
                        {
                            hp -= damage;
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("激化              ");
                            Console.WriteLine($"{name} get {skill.damage} damage");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            if (skill.element.quantity <= element.quantity)
                            {
                                quikenQ += skill.element.quantity;
                            }
                            else if (skill.element.quantity > element.quantity)
                            {
                                quikenQ += element.quantity;
                            }
                            element.quantity -= skill.element.quantity;

                            state = State.Quiken;
                        }
                        element.elementLevel = skill.element.elementLevel;
                        break;
                    }
                    //dendro element reaction
                case ElementType.Dendro:
                    if (skill.element.elementType == ElementType.Dendro)
                    {
                        hp -= damage;
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("                   ");
                        Console.WriteLine($"{name} get {skill.damage} damage");
                        Console.ForegroundColor = ConsoleColor.Gray;
                        SameElemental(skill.element);
                    }
                    else if (skill.element.elementType == ElementType.Electro)
                    {
                        hp -= damage;
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("激化                 ");
                        Console.WriteLine($"{name} get {skill.damage} damage");
                        Console.ForegroundColor = ConsoleColor.Gray;
                        if (skill.element.quantity <= element.quantity)
                        {
                            quikenQ += skill.element.quantity;
                        }
                        else if (skill.element.quantity > element.quantity)
                        {
                            quikenQ += element.quantity;
                        }
                        element.quantity -= skill.element.quantity;

                        state = State.Quiken;
                    }
                    else if (skill.element.elementType == ElementType.Water)
                    {
                        hp -= 1.5f * damage;
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("绽放               ");
                        Console.WriteLine($"{name} get {skill.damage} damage");
                        Console.ForegroundColor = ConsoleColor.Gray;
                        if (skill.element.quantity <= element.quantity)
                        {
                            bloomQ += 0.5f * skill.element.quantity;
                        }
                        else if (skill.element.quantity > element.quantity)
                        {
                            bloomQ += element.quantity;
                        }
                        element.quantity -= 0.5f * skill.element.quantity;

                        state = State.Bloom;
                    }
                    else if (skill.element.elementType == ElementType.Ice)
                    {
                        hp -= 1.5f * damage;
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("                  ");
                        Console.WriteLine($"{name} get {skill.damage} damage");
                        Console.ForegroundColor = ConsoleColor.Gray;
                        
                    }
                    else if (skill.element.elementType == ElementType.Fire)
                    {

                        hp -= damage;
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("燃烧                  ");
                        Console.WriteLine($"{name} get {skill.damage} damage");
                        Console.ForegroundColor = ConsoleColor.Gray;
                        if (skill.element.quantity <= element.quantity)
                        {
                            burnQ += skill.element.quantity;
                        }
                        else if (skill.element.quantity > element.quantity)
                        {
                            burnQ += element.quantity;

                        }
                        state = State.Burning;
                    }
                    element.elementLevel = skill.element.elementLevel;
                    break;
            }
            if (hp <= 0) hp = 0;
            Console.WriteLine($"Rest hp: {hp}");
            return element;
        }
        public void SameElemental(Element element)
        {
            if(this.element.elementType != ElementType.None)
            {
                if(element.quantity <= this.element.quantity)
                {
                    if(this.element.elementLevel == ElementLevel.S)
                    {
                        this.element.quantity = Element.Squantity * 0.8f;
                    }
                    else if (this.element.elementLevel == ElementLevel.M)
                    {
                        this.element.quantity = Element.Mquantity * 0.75f;
                    }
                    else if (this.element.elementLevel == ElementLevel.s)
                    {
                        this.element.quantity = Element.squantity * 0.7f;
                    }

                }
                else
                {
                    this.element.quantity = element.quantity;
                }
            }
/*            if(Element.ElementalLevel == ElementalLevel.S)
            {
                this.Element.quantity -=  Element.Squantity * 0.8f / 17;
            }
            else if(Element.ElementalLevel == ElementalLevel.M)
            {
                this.Element.quantity -= Element.Mquantity * 0.8f / 12;
            }
            else if(Element.ElementalLevel == ElementalLevel.s)
            {
                this.Element.quantity -= Element.squantity * 0.8f / 9;
            }*/
            
        }
    }
}
