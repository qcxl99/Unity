﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ConsoleHungrySnake
{
    class Program
    {
        static int height = 20;
        static int width = 20;
        static int ox = 5;
        static int oy = 5;
        static string[,] buffer = new string[width + ox, height + oy];
        static string[,] backbuffer = new string[buffer.GetLength(0), buffer.GetLength(1)];
        static ConsoleColor[,] colorbuffer = new ConsoleColor[buffer.GetLength(0), buffer.GetLength(1)];
        static Snake snake = new Snake(1, 1);
        static int itemPos;
        static int score;
        
        static void Main(string[] args)
        {
            int wait = 200;// wait ms, related to speed 
            snake.AddPos();
            snake.AddPos();
            snake.AddPos();
            snake.AddPos();
            itemPos = new Random().Next(5, height -1);
            bool stop = false;
            while (!stop)
            {
                
                //input to change direction
                ConsoleKeyInfo input = new ConsoleKeyInfo();
                while (Console.KeyAvailable)
                {
                    input = Console.ReadKey(true);
                    
                }
                
                snake.ChangeDir(input);
               
                //update state
                //snake move
                snake.Move();
                //Eat Item
                if (itemPos == snake.headX && itemPos == snake.headY)
                {
                    snake.AddPos();
                    score++;
                    itemPos = new Random().Next(1, height - 1);
                    // prevent item appear within snake
                    foreach (var s in snake.snakePos)
                    {
                        if (itemPos == s.posX && itemPos == s.posY)
                        {
                            itemPos = new Random().Next(s.posX, height - 1);
                        }
                    }
                }
                //snake was out of the border

                if (snake.headX <= 0 || snake.headX >= width-1 || snake.headY <= 0 || snake.headY >= height-1)
                {
                    break;
                }
                //snake touched itself
                for (int i = 1; i < snake.snakePos.Count - 1; i++)
                {
                    if (snake.snakeState != SnakeState.none && snake.snakePos[0].Equals(snake.snakePos[i]))
                    {
                        
                        stop = true;
                        break;
                        
                    }
                }
                
                if (snake.snakePos.Count > 20)
                {
                    wait = 150;
                }
                else if (snake.snakePos.Count > 50)
                {
                    wait = 100;
                }
                Thread.Sleep(wait);
                // Rendering
                Refresh();
                
            }
            //gmae over text
            Console.SetCursorPosition(ox , oy + height);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("GameOver");
            Console.ForegroundColor = ConsoleColor.Gray;
        }
        public static void Refresh()
        {
            //Clear buffer
            Copybuffer();
            for (int i = 0; i < buffer.GetLength(0); i++)
            {
                for (int j = 0; j < buffer.GetLength(1); j++)
                {
                    buffer[i, j] = " ";
                    colorbuffer[i, j] = ConsoleColor.Gray;
                }
            }
            //map buffer
            for (int i = oy; i < height + oy; i++)
            {
                for (int j = ox; j < width + ox; j++)
                {
                    if (i == oy)
                    {
                        buffer[i, j] = "#";
                    }
                    else if (i == height + oy - 1)
                    {
                        buffer[i, j] = "#";
                    }
                    else if (j == ox)
                    {
                        buffer[i, j] = "#";
                    }
                    else if (j == width + ox - 1)
                    {
                        buffer[i, j] = "#";
                    }
/*                    else
                    {
                        buffer[i, j] = " ";
                    }*/
                }
            }
            //draw item
            CreateItem(itemPos);
            // draw snake
            int snakeX = snake.snakePos[0].posX;
            int snakeY = snake.snakePos[0].posY;
            buffer[snakeY + oy, snakeX + ox] = "O";
            colorbuffer[snakeY + oy, snakeX + ox] = ConsoleColor.Green;
            for (int i = 1; i< snake.snakePos.Count -1; i++)
            {
                snakeX = snake.snakePos[i].posX;
                snakeY = snake.snakePos[i].posY;
                buffer[snakeY + oy, snakeX + ox] = "o";
                colorbuffer[snakeY + oy, snakeX + ox] = ConsoleColor.Green;
            }



            //stringbuilder to save buffer and then once print all
            /*            DateTime startTime = DateTime.Now;
                        //无颜色，但打印效率提高3倍左右，频闪程度大幅降低
                        StringBuilder stringBuilder = new StringBuilder();

                        for (int i = 0; i < buffer.GetLength(0); i++)
                        {
                            for (int j = 0; j < buffer.GetLength(1); j++)
                            {
                                if(backbuffer[i,j] != buffer[i, j])
                                {

                                }
                                stringBuilder.Append(buffer[i, j]);
                                stringBuilder.Append(" ");
                            }
                            stringBuilder.Append("\n");
                        }
                        Console.Clear();
                        Console.WriteLine(stringBuilder);
            */
            //有颜色，但屏闪太严重
            //用了colorcanvas的代码,解决了屏闪问题
            for (int i = 0; i < buffer.GetLength(0); i++)
            {
                int end = 0;
                for (int j = buffer.GetLength(1) - 1; j >= 0; j--)
                {
                    if (buffer[i, j] != " " || backbuffer[i, j] != " ")
                    {
                        end = j+1;
                        break;
                    }
                }
                for (int j = 0; j < end ; j++)
                {
                    if (backbuffer[i, j] != buffer[i, j])
                    {
                        Console.SetCursorPosition(j * 2, i);
                        Console.ForegroundColor = colorbuffer[i, j];
                        Console.Write(buffer[i, j]);
                    }
                }
            }
            //print score
            //buffer[ox - 1, oy] = "Score: " + score;
            Console.ForegroundColor =  ConsoleColor.Gray;
            Console.SetCursorPosition(ox+5, oy-1);
            Console.Write($"Score: {score}");
            /*            DateTime endTime = DateTime.Now;
                        Console.WriteLine((endTime - startTime).TotalMilliseconds);*/
        }
        public static void CreateItem(int itemPos)
        {
            buffer[itemPos + ox, itemPos + oy] = "*";
            colorbuffer[itemPos + ox, itemPos + oy] = ConsoleColor.Red;

        }
        public static void Copybuffer()
        {
            for (int i = 0; i < buffer.GetLength(0); i++)
            {
                for (int j = 0; j < buffer.GetLength(1); j++)
                {
                    backbuffer[i, j] = buffer[i, j];
                }
            }

        }
    }
}
