﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ConsoleHungrySnake
{
    public enum SnakeState
    {
        none,
        up,
        down,
        left,
        right,
        
    }
    class Snake
    {
        public SnakeState snakeState;
        public int headX = 1;
        public int headY = 1;
        public struct SnakePos
        {
            public int posX;
            public int posY;
            public SnakePos(int posX, int posY)
            {
                this.posX = posX;
                this.posY = posY;
            }
        }
        public List<SnakePos> snakePos = new List<SnakePos>() { new SnakePos(1,1) };

        public Snake()
        {
        }

        public Snake(int headX, int headY)
        {
            this.headX = headX;
            this.headY = headY;

        }

        public void AddPos()
        {
            snakePos.Add(snakePos[snakePos.Count-1]);
        }
        public void Move()
        {

            snakePos[0] = new SnakePos(headX, headY);
            switch (snakeState)
            {
                case SnakeState.none:
                    {
                        headX = headY = 1;
                        break;
                    }
                case SnakeState.up:
                    {
                        headY--;

                        break;
                    }
                case SnakeState.down:
                    {
                        headY++;

                        break;
                    }
                case SnakeState.left:
                    {
                        headX--;
                        break;
                    }
                case SnakeState.right:
                    {
                        headX++;
                        break;
                    }
                default:
                    {
                        snakeState = SnakeState.none;
                        break;
                    }
            }

            /*            for(int i =1; i<snakePos.Count -1; i++)
                        {
                            snakePos[i] = snakePos[i-1];
                        }*/
            for (int i = snakePos.Count - 1; i > 0; i--)
            {
                snakePos[i] = snakePos[i - 1];
            }
            snakePos[0] = new SnakePos(headX, headY) ;
        }
        public void ChangeDir(ConsoleKeyInfo input)
        {
            switch (input.Key)
            {
                case ConsoleKey.UpArrow:
                    {
                        if(snakeState == SnakeState.down) { return; }
                        else if (snakeState != SnakeState.up)
                        {
                            snakeState = SnakeState.up;
                        }
                        break;
                    }
                case ConsoleKey.DownArrow:
                    {
                        if (snakeState == SnakeState.up) { return; }
                        else if (snakeState != SnakeState.down)
                        {
                            snakeState = SnakeState.down;
                        }
                        break;
                    }
                case ConsoleKey.LeftArrow:
                    {

                        if (snakeState == SnakeState.right) { return; }
                        else if (snakeState != SnakeState.left)
                        {
                            snakeState = SnakeState.left;
                        }
                        break;
                    }
                case ConsoleKey.RightArrow:
                    {

                        if (snakeState == SnakeState.left) { return; }
                        else if (snakeState != SnakeState.right)
                        {
                            snakeState = SnakeState.right;
                        }
                        break;
                    }
               
            }

        }
    }

}
